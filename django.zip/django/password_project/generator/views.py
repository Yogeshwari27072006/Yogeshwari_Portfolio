from django.shortcuts import render
import random

def home(request):
    length = request.GET.get('length', '8')
    try:
        length = int(length)
    except (TypeError, ValueError):
        length = 8

    if length < 6:
        length = 6

    return render(request, 'generator/home.html', {'length': length})

def password(request):
    characters = list('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()')

    length = request.GET.get('length', '8')
    try:
        length = int(length)
    except (TypeError, ValueError):
        length = 8

    if length < 6:
        length = 6

    password = ''.join(random.choice(characters) for _ in range(length))

    return render(request, 'generator/password.html', {'password': password})